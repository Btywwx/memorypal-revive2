import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:memorypal_revive/models/photo_model.dart';

/// 照片详情页面 - 支持手势缩放和滑动浏览
class PhotoDetailScreen extends StatefulWidget {
  final PhotoModel photo;
  final List<PhotoModel> photos;

  const PhotoDetailScreen({
    super.key,
    required this.photo,
    required this.photos,
  });

  @override
  State<PhotoDetailScreen> createState() => _PhotoDetailScreenState();
}

class _PhotoDetailScreenState extends State<PhotoDetailScreen> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.photos.indexWhere((p) => p.id == widget.photo.id);
    _pageController = PageController(initialPage: _currentIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  PhotoModel get _currentPhoto => widget.photos[_currentIndex];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          '${_currentIndex + 1}/${widget.photos.length}',
          style: const TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, color: Colors.white),
            onPressed: _showPhotoInfo,
          ),
        ],
      ),
      body: Stack(
        children: [
          // 照片查看器
          PhotoViewGallery.builder(
            pageController: _pageController,
            itemCount: widget.photos.length,
            builder: (context, index) {
              final photo = widget.photos[index];
              return PhotoViewGalleryPageOptions(
                imageProvider: FileImage(File(photo.filePath)),
                minScale: PhotoViewComputedScale.contained,
                maxScale: PhotoViewComputedScale.covered * 2.0,
                heroAttributes: PhotoViewHeroAttributes(
                  tag: 'photo_${photo.id}',
                ),
              );
            },
            onPageChanged: _onPageChanged,
            backgroundDecoration: const BoxDecoration(
              color: Colors.black,
            ),
            enableRotation: true,
          ),
          
          // 底部信息栏
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 80,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.transparent,
                  ],
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // 照片信息
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _formatDate(_currentPhoto.createTime),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          if (_currentPhoto.width != null && _currentPhoto.height != null)
                            Text(
                              '${_currentPhoto.width}×${_currentPhoto.height}',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontSize: 12,
                              ),
                            ),
                        ],
                      ),
                    ),
                    
                    // 分享按钮
                    IconButton(
                      icon: const Icon(Icons.share, color: Colors.white),
                      onPressed: () => _sharePhoto(_currentPhoto),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPhotoInfo() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
          ),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              '照片信息',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 16),
            _buildInfoRow('拍摄时间', _formatDate(_currentPhoto.createTime, showTime: true)),
            if (_currentPhoto.width != null && _currentPhoto.height != null)
              _buildInfoRow('尺寸', '${_currentPhoto.width} × ${_currentPhoto.height}'),
            if (_currentPhoto.fileSize != null)
              _buildInfoRow('文件大小', _formatFileSize(_currentPhoto.fileSize!)),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('关闭'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Text(
            '$title: ',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.grey.shade700,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  void _sharePhoto(PhotoModel photo) {
    // TODO: 实现照片分享功能
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('准备分享照片: ${_formatDate(photo.createTime)}'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatDate(DateTime? date, {bool showTime = false}) {
    if (date == null) return '未知时间';
    
    final now = DateTime.now();
    final difference = now.difference(date);
    
    String dateStr;
    if (difference.inDays == 0) {
      dateStr = '今天';
    } else if (difference.inDays == 1) {
      dateStr = '昨天';
    } else if (difference.inDays < 7) {
      dateStr = '${difference.inDays}天前';
    } else {
      dateStr = '${date.year}年${date.month}月${date.day}日';
    }
    
    if (showTime) {
      return '$dateStr ${_formatTime(date)}';
    }
    
    return dateStr;
  }

  String _formatTime(DateTime date) {
    return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  String _formatFileSize(double size) {
    if (size < 1024) {
      return '${size.toStringAsFixed(0)} B';
    } else if (size < 1024 * 1024) {
      return '${(size / 1024).toStringAsFixed(1)} KB';
    } else {
      return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
  }
}