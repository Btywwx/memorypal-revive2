import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
// import 'package:photo_view/photo_view.dart';
import 'package:memorypal_revive/models/photo_model.dart';
import 'package:memorypal_revive/utils/performance_monitor.dart';
import 'package:memorypal_revive/widgets/tablet_optimized_layout.dart';

/// 全屏幻灯片播放屏幕 - 为平板设备优化
class SlideshowScreen extends StatefulWidget {
  final List<PhotoModel> photos;
  final int initialIndex;

  const SlideshowScreen({
    super.key,
    required this.photos,
    required this.initialIndex,
  });

  @override
  State<SlideshowScreen> createState() => _SlideshowScreenState();
}

class _SlideshowScreenState extends State<SlideshowScreen> with SingleTickerProviderStateMixin {
  late PageController _pageController;
  late Timer _slideshowTimer;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  
  int _currentIndex = 0;
  bool _isPlaying = true;
  bool _showControls = true;
  Duration _slideDuration = const Duration(seconds: 5);
  
  // 幻灯片播放模式
  SlideshowMode _mode = SlideshowMode.sequential;
  
  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: _currentIndex);
    
    // 动画控制器
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    
    // 启动幻灯片播放
    _startSlideshow();
    
    // 自动隐藏控制面板
    _hideControlsAfterDelay();
  }

  @override
  void dispose() {
    _slideshowTimer.cancel();
    _animationController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _startSlideshow() {
    if (!_isPlaying) return;
    
    _slideshowTimer = Timer.periodic(_slideDuration, (timer) {
      if (_isPlaying) {
        _nextSlide();
      }
    });
  }

  void _stopSlideshow() {
    _slideshowTimer.cancel();
    _isPlaying = false;
  }

  void _togglePlayPause() {
    setState(() {
      _isPlaying = !_isPlaying;
      if (_isPlaying) {
        _startSlideshow();
      } else {
        _stopSlideshow();
      }
    });
    _showControlsTemporarily();
  }

  void _nextSlide() {
    if (_currentIndex < widget.photos.length - 1) {
      _currentIndex++;
    } else {
      if (_mode == SlideshowMode.loop) {
        _currentIndex = 0;
      } else {
        _stopSlideshow();
        return;
      }
    }
    
    _animateTransition();
  }

  void _previousSlide() {
    if (_currentIndex > 0) {
      _currentIndex--;
    } else {
      if (_mode == SlideshowMode.loop) {
        _currentIndex = widget.photos.length - 1;
      }
    }
    
    _animateTransition();
  }

  void _animateTransition() {
    _animationController.reset();
    _animationController.forward();
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _pageController.animateToPage(
        _currentIndex,
        duration: const Duration(milliseconds: 800),
        curve: Curves.easeInOut,
      );
    });
  }

  void _onPageChanged(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void _showControlsTemporarily() {
    setState(() {
      _showControls = true;
    });
    _hideControlsAfterDelay();
  }

  void _hideControlsAfterDelay() {
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted && _isPlaying) {
        setState(() {
          _showControls = false;
        });
      }
    });
  }

  void _changeDuration(Duration newDuration) {
    setState(() {
      _slideDuration = newDuration;
    });
    
    if (_isPlaying) {
      _stopSlideshow();
      _startSlideshow();
    }
    
    _showControlsTemporarily();
  }

  void _changeMode(SlideshowMode newMode) {
    setState(() {
      _mode = newMode;
    });
    _showControlsTemporarily();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _showControlsTemporarily,
        child: Stack(
          children: [
            // 幻灯片内容
            PageView.builder(
              controller: _pageController,
              itemCount: widget.photos.length,
              onPageChanged: _onPageChanged,
              itemBuilder: (context, index) {
                final photo = widget.photos[index];
                return AnimatedBuilder(
                  animation: _fadeAnimation,
                  builder: (context, child) {
                    return Opacity(
                      opacity: _fadeAnimation.value,
                      child: Container(
                        color: Colors.black,
                        child: Center(
                          child: Hero(
                            tag: 'photo_${photo.id}',
                            child: Image.file(
                              File(photo.filePath),
                              fit: BoxFit.contain,
                              width: double.infinity,
                              height: double.infinity,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: Colors.grey.shade900,
                                  child: Center(
                                    child: Icon(
                                      Icons.broken_image,
                                      size: 64,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
            
            // 顶部控制栏
            AnimatedPositioned(
              duration: const Duration(milliseconds: 300),
              top: _showControls ? 0 : -100,
              left: 0,
              right: 0,
              child: Container(
                height: 100,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.8),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Row(
                      children: [
                        // 返回按钮
                        IconButton(
                          icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                        
                        const Spacer(),
                        
                        // 幻灯片信息
                        Text(
                          '${_currentIndex + 1}/${widget.photos.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        
                        const Spacer(),
                        
                        // 模式选择
                        PopupMenuButton<SlideshowMode>(
                          icon: const Icon(Icons.settings, color: Colors.white, size: 28),
                          onSelected: _changeMode,
                          itemBuilder: (context) => [
                            PopupMenuItem(
                              value: SlideshowMode.sequential,
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.arrow_forward,
                                    color: _mode == SlideshowMode.sequential ? Colors.blue : Colors.grey,
                                  ),
                                  const SizedBox(width: 8),
                                  const Text('顺序播放'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: SlideshowMode.loop,
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.repeat,
                                    color: _mode == SlideshowMode.loop ? Colors.blue : Colors.grey,
                                  ),
                                  const SizedBox(width: 8),
                                  const Text('循环播放'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: SlideshowMode.random,
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.shuffle,
                                    color: _mode == SlideshowMode.random ? Colors.blue : Colors.grey,
                                  ),
                                  const SizedBox(width: 8),
                                  const Text('随机播放'),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            
            // 底部控制栏
            AnimatedPositioned(
              duration: const Duration(milliseconds: 300),
              bottom: _showControls ? 0 : -120,
              left: 0,
              right: 0,
              child: Container(
                height: 120,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Colors.black.withOpacity(0.8),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    children: [
                      // 进度条
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: LinearProgressIndicator(
                          value: widget.photos.isEmpty ? 0 : (_currentIndex + 1) / widget.photos.length,
                          backgroundColor: Colors.grey.shade700,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.blue.shade400),
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // 控制按钮
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // 上一张
                          IconButton(
                            icon: const Icon(Icons.skip_previous, color: Colors.white, size: 32),
                            onPressed: _previousSlide,
                          ),
                          
                          const SizedBox(width: 20),
                          
                          // 播放/暂停
                          IconButton(
                            icon: Icon(
                              _isPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.white,
                              size: 40,
                            ),
                            onPressed: _togglePlayPause,
                          ),
                          
                          const SizedBox(width: 20),
                          
                          // 下一张
                          IconButton(
                            icon: const Icon(Icons.skip_next, color: Colors.white, size: 32),
                            onPressed: _nextSlide,
                          ),
                          
                          const SizedBox(width: 20),
                          
                          // 速度控制
                          PopupMenuButton<Duration>(
                            icon: const Icon(Icons.speed, color: Colors.white, size: 28),
                            onSelected: _changeDuration,
                            itemBuilder: (context) => [
                              PopupMenuItem(
                                value: const Duration(seconds: 3),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.fast_forward,
                                      color: _slideDuration == const Duration(seconds: 3) ? Colors.blue : Colors.grey,
                                    ),
                                    const SizedBox(width: 8),
                                    const Text('快速 (3秒)'),
                                  ],
                                ),
                              ),
                              PopupMenuItem(
                                value: const Duration(seconds: 5),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.play_arrow,
                                      color: _slideDuration == const Duration(seconds: 5) ? Colors.blue : Colors.grey,
                                    ),
                                    const SizedBox(width: 8),
                                    const Text('标准 (5秒)'),
                                  ],
                                ),
                              ),
                              PopupMenuItem(
                                value: const Duration(seconds: 10),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.slow_motion_video,
                                      color: _slideDuration == const Duration(seconds: 10) ? Colors.blue : Colors.grey,
                                    ),
                                    const SizedBox(width: 8),
                                    const Text('慢速 (10秒)'),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            
            // 照片信息（仅在控制面板显示时显示）
            if (_showControls)
              Positioned(
                bottom: 120,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  child: Text(
                    _formatDate(widget.photos[_currentIndex].createTime),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime? date) {
    if (date == null) return '未知时间';
    
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      return '今天 ${_formatTime(date)}';
    } else if (difference.inDays == 1) {
      return '昨天 ${_formatTime(date)}';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}天前';
    } else {
      return '${date.year}年${date.month}月${date.day}日';
    }
  }

  String _formatTime(DateTime date) {
    return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }
}

/// 幻灯片播放模式
enum SlideshowMode {
  sequential, // 顺序播放
  loop,       // 循环播放
  random,     // 随机播放
}