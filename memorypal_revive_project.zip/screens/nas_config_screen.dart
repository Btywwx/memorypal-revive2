import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:memorypal_revive/providers/nas_provider.dart';
import 'package:memorypal_revive/models/nas_config.dart';

/// NAS配置管理屏幕
class NasConfigScreen extends StatefulWidget {
  const NasConfigScreen({super.key});

  @override
  State<NasConfigScreen> createState() => _NasConfigScreenState();
}

class _NasConfigScreenState extends State<NasConfigScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _hostController = TextEditingController();
  final _portController = TextEditingController(text: '445');
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _sharePathController = TextEditingController(text: '/photo');
  
  NasProtocol _selectedProtocol = NasProtocol.smb;
  bool _isDefault = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final nasProvider = Provider.of<NasProvider>(context, listen: false);
      nasProvider.loadConfigs();
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _hostController.dispose();
    _portController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    _sharePathController.dispose();
    super.dispose();
  }

  void _addNasConfig() {
    if (_formKey.currentState!.validate()) {
      final config = NasConfig(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text,
        host: _hostController.text,
        port: int.tryParse(_portController.text) ?? 445,
        username: _usernameController.text,
        password: _passwordController.text,
        sharePath: _sharePathController.text,
        protocol: _selectedProtocol,
        isDefault: _isDefault,
      );

      final nasProvider = Provider.of<NasProvider>(context, listen: false);
      nasProvider.addNasConfig(config);
      
      _clearForm();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('NAS配置已添加: ${config.name}')),
      );
    }
  }

  void _clearForm() {
    _formKey.currentState?.reset();
    _nameController.clear();
    _hostController.clear();
    _portController.text = '445';
    _usernameController.clear();
    _passwordController.clear();
    _sharePathController.text = '/photo';
    _selectedProtocol = NasProtocol.smb;
    _isDefault = false;
  }

  void _testConnection(NasConfig config) {
    final nasProvider = Provider.of<NasProvider>(context, listen: false);
    nasProvider.connectToNas(config).then((_) {
      final status = nasProvider.connectionStatus;
      if (status == NasConnectionStatus.connected) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('连接成功')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('连接失败: ${nasProvider.syncError}')),
        );
      }
    });
  }

  Widget _buildProtocolIcon(NasProtocol protocol) {
    switch (protocol) {
      case NasProtocol.smb:
        return const Icon(Icons.storage, color: Colors.blue);
      case NasProtocol.webdav:
        return const Icon(Icons.cloud, color: Colors.green);
      case NasProtocol.ftp:
        return const Icon(Icons.file_upload, color: Colors.orange);
    }
  }

  Widget _buildConnectionStatus(NasConnectionStatus status) {
    switch (status) {
      case NasConnectionStatus.disconnected:
        return Row(
          children: [
            Icon(Icons.circle, color: Colors.grey.shade400, size: 12),
            const SizedBox(width: 4),
            Text('未连接', style: TextStyle(color: Colors.grey.shade600)),
          ],
        );
      case NasConnectionStatus.connecting:
        return Row(
          children: [
            SizedBox(
              width: 12,
              height: 12,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            const SizedBox(width: 4),
            const Text('连接中...', style: TextStyle(color: Colors.orange)),
          ],
        );
      case NasConnectionStatus.connected:
        return Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green.shade600, size: 12),
            const SizedBox(width: 4),
            const Text('已连接', style: TextStyle(color: Colors.green)),
          ],
        );
      case NasConnectionStatus.error:
        return Row(
          children: [
            Icon(Icons.error, color: Colors.red.shade600, size: 12),
            const SizedBox(width: 4),
            const Text('连接错误', style: TextStyle(color: Colors.red)),
          ],
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NAS网络存储配置'),
        backgroundColor: Colors.blue.shade50,
        elevation: 0,
      ),
      body: Consumer<NasProvider>(
        builder: (context, nasProvider, child) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // 添加配置表单
                Card(
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            '添加NAS配置',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 16),
                          
                          // 配置名称
                          TextFormField(
                            controller: _nameController,
                            decoration: const InputDecoration(
                              labelText: '配置名称',
                              hintText: '例如：家庭NAS',
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return '请输入配置名称';
                              }
                              return null;
                            },
                          ),
                          
                          const SizedBox(height: 12),
                          
                          // 协议选择
                          DropdownButtonFormField<NasProtocol>(
                            value: _selectedProtocol,
                            decoration: const InputDecoration(labelText: '协议类型'),
                            items: NasProtocol.values.map((protocol) {
                              return DropdownMenuItem(
                                value: protocol,
                                child: Row(
                                  children: [
                                    _buildProtocolIcon(protocol),
                                    const SizedBox(width: 8),
                                    Text(_getProtocolName(protocol)),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedProtocol = value!;
                              });
                            },
                          ),
                          
                          const SizedBox(height: 12),
                          
                          Row(
                            children: [
                              // 主机地址
                              Expanded(
                                flex: 2,
                                child: TextFormField(
                                  controller: _hostController,
                                  decoration: const InputDecoration(
                                    labelText: '主机地址',
                                    hintText: '192.168.1.100',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return '请输入主机地址';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              const SizedBox(width: 12),
                              // 端口
                              Expanded(
                                flex: 1,
                                child: TextFormField(
                                  controller: _portController,
                                  decoration: const InputDecoration(labelText: '端口'),
                                  keyboardType: TextInputType.number,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return '请输入端口';
                                    }
                                    if (int.tryParse(value) == null) {
                                      return '请输入有效的端口号';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ],
                          ),
                          
                          const SizedBox(height: 12),
                          
                          // 用户名和密码
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                  controller: _usernameController,
                                  decoration: const InputDecoration(labelText: '用户名'),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return '请输入用户名';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: TextFormField(
                                  controller: _passwordController,
                                  decoration: const InputDecoration(labelText: '密码'),
                                  obscureText: true,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return '请输入密码';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ],
                          ),
                          
                          const SizedBox(height: 12),
                          
                          // 共享路径
                          TextFormField(
                            controller: _sharePathController,
                            decoration: const InputDecoration(
                              labelText: '共享路径',
                              hintText: '/photo',
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return '请输入共享路径';
                              }
                              return null;
                            },
                          ),
                          
                          const SizedBox(height: 12),
                          
                          // 默认配置和添加按钮
                          Row(
                            children: [
                              Checkbox(
                                value: _isDefault,
                                onChanged: (value) {
                                  setState(() {
                                    _isDefault = value ?? false;
                                  });
                                },
                              ),
                              const Text('设为默认配置'),
                              const Spacer(),
                              ElevatedButton(
                                onPressed: _addNasConfig,
                                child: const Text('添加配置'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                
                const SizedBox(height: 20),
                
                // 现有配置列表
                Expanded(
                  child: nasProvider.nasConfigs.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.storage, size: 64, color: Colors.grey),
                              SizedBox(height: 16),
                              Text('暂无NAS配置', style: TextStyle(color: Colors.grey)),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: nasProvider.nasConfigs.length,
                          itemBuilder: (context, index) {
                            final config = nasProvider.nasConfigs[index];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: _buildProtocolIcon(config.protocol),
                                title: Row(
                                  children: [
                                    Text(config.name),
                                    if (config.isDefault) ...[
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.blue.shade100,
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: const Text(
                                          '默认',
                                          style: TextStyle(fontSize: 10, color: Colors.blue),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(config.host),
                                    const SizedBox(height: 4),
                                    _buildConnectionStatus(nasProvider.connectionStatus),
                                  ],
                                ),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      icon: const Icon(Icons.play_arrow, size: 20),
                                      onPressed: () => _testConnection(config),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                                      onPressed: () {
                                        nasProvider.removeNasConfig(config.id);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  String _getProtocolName(NasProtocol protocol) {
    switch (protocol) {
      case NasProtocol.smb:
        return 'SMB/CIFS';
      case NasProtocol.webdav:
        return 'WebDAV';
      case NasProtocol.ftp:
        return 'FTP';
    }
  }
}