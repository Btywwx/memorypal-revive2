import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:exif/exif.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:memorypal_revive/models/photo_model.dart';

/// 照片状态管理类
class PhotoProvider with ChangeNotifier {
  List<PhotoModel> _photos = [];
  bool _isLoading = false;
  String? _error;
  PermissionStatus _permissionStatus = PermissionStatus.denied;

  List<PhotoModel> get photos => _photos;
  bool get isLoading => _isLoading;
  String? get error => _error;
  PermissionStatus get permissionStatus => _permissionStatus;

  /// 检查并请求相册权限
  Future<void> checkAndRequestPermission() async {
    _permissionStatus = await Permission.photos.status;
    
    if (!_permissionStatus.isGranted) {
      _permissionStatus = await Permission.photos.request();
    }
    
    notifyListeners();
  }

  /// 加载本地相册照片
  Future<void> loadLocalPhotos() async {
    if (_isLoading) return;

    // 先检查权限
    await checkAndRequestPermission();
    
    if (!_permissionStatus.isGranted) {
      _error = '相册权限被拒绝，请前往设置中开启权限';
      notifyListeners();
      return;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // 获取所有照片资源
      final List<AssetPathEntity> paths = await PhotoManager.getAssetPathList(
        type: RequestType.image,
        filterOption: FilterOptionGroup(
          imageOption: FilterOption(
            size: const Size(1000, 1000), // 限制图片大小，优化性能
          ),
        ),
      );

      if (paths.isEmpty) {
        _error = '未找到照片';
        _isLoading = false;
        notifyListeners();
        return;
      }

      // 获取所有相册的照片（最多1000张，避免内存问题）
      List<AssetEntity> allAssets = [];
      for (final path in paths) {
        final assets = await path.getAssetListPaged(
          page: 0,
          size: 200, // 每个相册最多加载200张
        );
        allAssets.addAll(assets);
        
        // 限制总数量，避免内存溢出
        if (allAssets.length >= 1000) {
          allAssets = allAssets.sublist(0, 1000);
          break;
        }
      }

      // 去重并按时间排序
      allAssets.sort((a, b) => b.createDateTime.compareTo(a.createDateTime));
      
      // 转换为PhotoModel（分批处理，避免内存问题）
      _photos = [];
      final batchSize = 50;
      for (int i = 0; i < allAssets.length; i += batchSize) {
        final batch = allAssets.sublist(
          i, 
          i + batchSize > allAssets.length ? allAssets.length : i + batchSize
        );
        
        final batchPhotos = await Future.wait(
          batch.map((asset) => _createPhotoModelFromAsset(asset)),
        );
        
        _photos.addAll(batchPhotos);
        notifyListeners(); // 分批通知更新UI
      }

    } catch (e) {
      _error = '加载照片失败: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 从AssetEntity创建PhotoModel
  Future<PhotoModel> _createPhotoModelFromAsset(AssetEntity asset) async {
    final file = await asset.file;
    final createTime = asset.createDateTime;
    
    // 生成缩略图路径
    final thumbnailFile = await asset.thumbnailData;
    String? thumbnailPath;
    
    // 读取EXIF信息
    String? exifInfo;
    if (file != null) {
      try {
        final bytes = await file.readAsBytes();
        final exifData = await readExifFromBytes(bytes);
        exifInfo = _formatExifInfo(exifData);
      } catch (e) {
        // EXIF读取失败不影响主流程
        exifInfo = null;
      }
    }
    
    return PhotoModel(
      id: asset.id,
      filePath: file?.path ?? '',
      thumbnailPath: thumbnailPath,
      createTime: createTime,
      width: asset.width,
      height: asset.height,
      fileSize: asset.size.toDouble(),
      exifInfo: exifInfo,
    );
  }

  /// 格式化EXIF信息
  String _formatExifInfo(Map<String, IfdTag> exifData) {
    final info = StringBuffer();
    
    // 相机信息
    if (exifData.containsKey('Image Make') && exifData.containsKey('Image Model')) {
      info.write('${exifData['Image Make']?.printable ?? ''} ${exifData['Image Model']?.printable ?? ''}\n');
    }
    
    // 拍摄参数
    if (exifData.containsKey('EXIF FNumber')) {
      info.write('光圈: f/${exifData['EXIF FNumber']?.printable ?? ''} ');
    }
    
    if (exifData.containsKey('EXIF ExposureTime')) {
      info.write('快门: ${exifData['EXIF ExposureTime']?.printable ?? ''} ');
    }
    
    if (exifData.containsKey('EXIF ISOSpeedRatings')) {
      info.write('ISO: ${exifData['EXIF ISOSpeedRatings']?.printable ?? ''}');
    }
    
    return info.toString().trim();
  }

  /// 清除错误信息
  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// 重新加载照片
  Future<void> refreshPhotos() async {
    await loadLocalPhotos();
  }

  /// 根据ID获取照片
  PhotoModel? getPhotoById(String id) {
    try {
      return _photos.firstWhere((photo) => photo.id == id);
    } catch (e) {
      return null;
    }
  }

  /// 按时间范围筛选照片
  List<PhotoModel> getPhotosByDateRange(DateTime start, DateTime end) {
    return _photos.where((photo) {
      if (photo.createTime == null) return false;
      return photo.createTime!.isAfter(start) && photo.createTime!.isBefore(end);
    }).toList();
  }

  /// 获取最近的照片
  List<PhotoModel> getRecentPhotos([int count = 10]) {
    return _photos.take(count).toList();
  }
}