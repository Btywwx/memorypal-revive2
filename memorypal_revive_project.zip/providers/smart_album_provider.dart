import 'package:flutter/foundation.dart';
import 'package:memorypal_revive/models/photo_model.dart';

/// 智能相册模型
class SmartAlbum {
  final String id;
  final String name;
  final String description;
  final SmartAlbumType type;
  final List<PhotoModel> photos;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? location;

  SmartAlbum({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.photos,
    this.startDate,
    this.endDate,
    this.location,
  });

  /// 获取相册封面照片
  PhotoModel? get coverPhoto {
    return photos.isNotEmpty ? photos.first : null;
  }

  /// 获取照片数量
  int get photoCount => photos.length;

  @override
  String toString() {
    return 'SmartAlbum(id: $id, name: $name, type: $type, photos: ${photos.length})';
  }
}

/// 智能相册类型
enum SmartAlbumType {
  recent,      // 最近添加
  favorites,   // 收藏
  timeline,    // 时间线
  location,    // 地点
  category,    // 分类
  custom,      // 自定义
}

/// 智能相册提供者
class SmartAlbumProvider with ChangeNotifier {
  List<SmartAlbum> _smartAlbums = [];
  List<PhotoModel> _allPhotos = [];

  List<SmartAlbum> get smartAlbums => _smartAlbums;

  /// 设置所有照片数据
  void setPhotos(List<PhotoModel> photos) {
    _allPhotos = photos;
    _generateSmartAlbums();
  }

  /// 生成智能相册
  void _generateSmartAlbums() {
    _smartAlbums = [
      // 最近添加相册
      SmartAlbum(
        id: 'recent',
        name: '最近添加',
        description: '最近添加的照片',
        type: SmartAlbumType.recent,
        photos: _getRecentPhotos(),
      ),
      
      // 本月相册
      SmartAlbum(
        id: 'this_month',
        name: '本月',
        description: '本月拍摄的照片',
        type: SmartAlbumType.timeline,
        photos: _getThisMonthPhotos(),
        startDate: DateTime(DateTime.now().year, DateTime.now().month, 1),
        endDate: DateTime(DateTime.now().year, DateTime.now().month + 1, 0),
      ),
      
      // 去年相册
      SmartAlbum(
        id: 'last_year',
        name: '去年',
        description: '去年拍摄的照片',
        type: SmartAlbumType.timeline,
        photos: _getLastYearPhotos(),
        startDate: DateTime(DateTime.now().year - 1, 1, 1),
        endDate: DateTime(DateTime.now().year - 1, 12, 31),
      ),
      
      // 收藏相册（模拟数据）
      SmartAlbum(
        id: 'favorites',
        name: '收藏',
        description: '您收藏的照片',
        type: SmartAlbumType.favorites,
        photos: _getFavoritePhotos(),
      ),
    ];
    
    // 移除空相册
    _smartAlbums = _smartAlbums.where((album) => album.photos.isNotEmpty).toList();
    
    notifyListeners();
  }

  /// 获取最近添加的照片（最近30天）
  List<PhotoModel> _getRecentPhotos() {
    final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));
    return _allPhotos.where((photo) {
      return photo.createTime != null && photo.createTime!.isAfter(thirtyDaysAgo);
    }).toList();
  }

  /// 获取本月照片
  List<PhotoModel> _getThisMonthPhotos() {
    final startOfMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);
    final endOfMonth = DateTime(DateTime.now().year, DateTime.now().month + 1, 0);
    
    return _allPhotos.where((photo) {
      return photo.createTime != null && 
             photo.createTime!.isAfter(startOfMonth) &&
             photo.createTime!.isBefore(endOfMonth);
    }).toList();
  }

  /// 获取去年照片
  List<PhotoModel> _getLastYearPhotos() {
    final startOfLastYear = DateTime(DateTime.now().year - 1, 1, 1);
    final endOfLastYear = DateTime(DateTime.now().year - 1, 12, 31);
    
    return _allPhotos.where((photo) {
      return photo.createTime != null && 
             photo.createTime!.isAfter(startOfLastYear) &&
             photo.createTime!.isBefore(endOfLastYear);
    }).toList();
  }

  /// 获取收藏照片（模拟数据 - 随机选择一些照片）
  List<PhotoModel> _getFavoritePhotos() {
    if (_allPhotos.isEmpty) return [];
    
    // 随机选择最多10张照片作为收藏
    final favorites = _allPhotos.take(10).toList();
    return favorites;
  }

  /// 根据时间范围筛选照片
  List<PhotoModel> getPhotosByDateRange(DateTime start, DateTime end) {
    return _allPhotos.where((photo) {
      return photo.createTime != null && 
             photo.createTime!.isAfter(start) &&
             photo.createTime!.isBefore(end);
    }).toList();
  }

  /// 根据年份筛选照片
  List<PhotoModel> getPhotosByYear(int year) {
    final startOfYear = DateTime(year, 1, 1);
    final endOfYear = DateTime(year, 12, 31);
    
    return getPhotosByDateRange(startOfYear, endOfYear);
  }

  /// 根据月份筛选照片
  List<PhotoModel> getPhotosByMonth(int year, int month) {
    final startOfMonth = DateTime(year, month, 1);
    final endOfMonth = DateTime(year, month + 1, 0);
    
    return getPhotosByDateRange(startOfMonth, endOfMonth);
  }

  /// 获取所有年份列表
  List<int> getAvailableYears() {
    final years = <int>{};
    for (final photo in _allPhotos) {
      if (photo.createTime != null) {
        years.add(photo.createTime!.year);
      }
    }
    return years.toList()..sort((a, b) => b.compareTo(a));
  }

  /// 获取指定年份的月份列表
  List<int> getAvailableMonths(int year) {
    final months = <int>{};
    for (final photo in _allPhotos) {
      if (photo.createTime != null && photo.createTime!.year == year) {
        months.add(photo.createTime!.month);
      }
    }
    return months.toList()..sort((a, b) => b.compareTo(a));
  }

  /// 创建自定义智能相册
  void createCustomAlbum({
    required String name,
    required String description,
    List<PhotoModel>? photos,
    DateTime? startDate,
    DateTime? endDate,
    String? location,
  }) {
    final album = SmartAlbum(
      id: 'custom_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      description: description,
      type: SmartAlbumType.custom,
      photos: photos ?? [],
      startDate: startDate,
      endDate: endDate,
      location: location,
    );
    
    _smartAlbums.add(album);
    notifyListeners();
  }

  /// 删除自定义相册
  void deleteCustomAlbum(String id) {
    _smartAlbums.removeWhere((album) => album.id == id && album.type == SmartAlbumType.custom);
    notifyListeners();
  }

  /// 更新相册照片
  void updateAlbumPhotos(String albumId, List<PhotoModel> photos) {
    final index = _smartAlbums.indexWhere((album) => album.id == albumId);
    if (index != -1) {
      _smartAlbums[index] = SmartAlbum(
        id: _smartAlbums[index].id,
        name: _smartAlbums[index].name,
        description: _smartAlbums[index].description,
        type: _smartAlbums[index].type,
        photos: photos,
        startDate: _smartAlbums[index].startDate,
        endDate: _smartAlbums[index].endDate,
        location: _smartAlbums[index].location,
      );
      notifyListeners();
    }
  }

  /// 搜索照片
  List<PhotoModel> searchPhotos(String query) {
    if (query.isEmpty) return [];
    
    return _allPhotos.where((photo) {
      // 根据文件名搜索
      if (photo.filePath.toLowerCase().contains(query.toLowerCase())) {
        return true;
      }
      
      // 根据日期搜索
      if (photo.createTime != null) {
        final dateString = '${photo.createTime!.year}年${photo.createTime!.month}月${photo.createTime!.day}日';
        if (dateString.contains(query)) {
          return true;
        }
      }
      
      // 根据EXIF信息搜索
      if (photo.exifInfo != null && photo.exifInfo!.toLowerCase().contains(query.toLowerCase())) {
        return true;
      }
      
      return false;
    }).toList();
  }

  /// 获取相册统计信息
  Map<String, dynamic> getAlbumStats() {
    return {
      'totalAlbums': _smartAlbums.length,
      'totalPhotos': _allPhotos.length,
      'recentCount': _getRecentPhotos().length,
      'thisMonthCount': _getThisMonthPhotos().length,
      'lastYearCount': _getLastYearPhotos().length,
      'favoritesCount': _getFavoritePhotos().length,
    };
  }
}