import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import 'package:memorypal_revive/models/nas_config.dart';
import 'package:memorypal_revive/models/photo_model.dart';

/// NAS网络存储提供者
class NasProvider with ChangeNotifier {
  List<NasConfig> _nasConfigs = [];
  NasConnectionStatus _connectionStatus = NasConnectionStatus.disconnected;
  bool _isSyncing = false;
  String? _syncError;
  List<PhotoModel> _nasPhotos = [];

  List<NasConfig> get nasConfigs => _nasConfigs;
  NasConnectionStatus get connectionStatus => _connectionStatus;
  bool get isSyncing => _isSyncing;
  String? get syncError => _syncError;
  List<PhotoModel> get nasPhotos => _nasPhotos;

  /// 添加NAS配置
  void addNasConfig(NasConfig config) {
    _nasConfigs.add(config);
    notifyListeners();
    _saveConfigs();
  }

  /// 更新NAS配置
  void updateNasConfig(NasConfig config) {
    final index = _nasConfigs.indexWhere((c) => c.id == config.id);
    if (index != -1) {
      _nasConfigs[index] = config;
      notifyListeners();
      _saveConfigs();
    }
  }

  /// 删除NAS配置
  void removeNasConfig(String id) {
    _nasConfigs.removeWhere((config) => config.id == id);
    notifyListeners();
    _saveConfigs();
  }

  /// 设置默认NAS配置
  void setDefaultNasConfig(String id) {
    for (final config in _nasConfigs) {
      config.isDefault = config.id == id;
    }
    notifyListeners();
    _saveConfigs();
  }

  /// 获取默认NAS配置
  NasConfig? getDefaultNasConfig() {
    try {
      return _nasConfigs.firstWhere((config) => config.isDefault);
    } catch (e) {
      return _nasConfigs.isNotEmpty ? _nasConfigs.first : null;
    }
  }

  /// 连接到NAS
  Future<void> connectToNas(NasConfig config) async {
    if (_isSyncing) return;

    _connectionStatus = NasConnectionStatus.connecting;
    _syncError = null;
    notifyListeners();

    try {
      // 模拟连接过程（实际项目中需要实现具体协议）
      await Future.delayed(const Duration(seconds: 2));
      
      // 这里应该根据协议类型实现具体的连接逻辑
      switch (config.protocol) {
        case NasProtocol.smb:
          await _connectViaSmb(config);
          break;
        case NasProtocol.webdav:
          await _connectViaWebdav(config);
          break;
        case NasProtocol.ftp:
          await _connectViaFtp(config);
          break;
      }
      
      _connectionStatus = NasConnectionStatus.connected;
      notifyListeners();
      
    } catch (e) {
      _connectionStatus = NasConnectionStatus.error;
      _syncError = '连接失败: $e';
      notifyListeners();
    }
  }

  /// 同步NAS照片
  Future<void> syncNasPhotos(NasConfig config) async {
    if (_isSyncing) return;

    _isSyncing = true;
    _syncError = null;
    notifyListeners();

    try {
      // 先连接到NAS
      await connectToNas(config);
      
      if (_connectionStatus != NasConnectionStatus.connected) {
        throw Exception('NAS连接失败');
      }

      // 获取NAS上的照片列表
      final photos = await _getNasPhotos(config);
      
      // 下载缩略图（分批处理，避免内存问题）
      final List<PhotoModel> downloadedPhotos = [];
      final batchSize = 10;
      
      for (int i = 0; i < photos.length; i += batchSize) {
        final batch = photos.sublist(
          i, 
          i + batchSize > photos.length ? photos.length : i + batchSize
        );
        
        final batchPhotos = await Future.wait(
          batch.map((photo) => _downloadPhotoThumbnail(photo, config)),
        );
        
        downloadedPhotos.addAll(batchPhotos);
        notifyListeners(); // 分批通知更新UI
      }
      
      _nasPhotos = downloadedPhotos;
      _isSyncing = false;
      notifyListeners();
      
    } catch (e) {
      _isSyncing = false;
      _syncError = '同步失败: $e';
      notifyListeners();
    }
  }

  /// 断开NAS连接
  void disconnectNas() {
    _connectionStatus = NasConnectionStatus.disconnected;
    _nasPhotos.clear();
    notifyListeners();
  }

  /// 模拟SMB连接
  Future<void> _connectViaSmb(NasConfig config) async {
    // 实际项目中需要使用SMB协议库
    await Future.delayed(const Duration(seconds: 1));
    
    // 模拟连接测试
    if (config.host.isEmpty) {
      throw Exception('主机地址不能为空');
    }
  }

  /// 模拟WebDAV连接
  Future<void> _connectViaWebdav(NasConfig config) async {
    // 实际项目中需要使用WebDAV协议
    final dio = Dio();
    
    try {
      final response = await dio.get(
        config.connectionUrl,
        options: Options(
          headers: {
            'Authorization': 'Basic ${_encodeCredentials(config.username, config.password)}',
          },
        ),
      );
      
      if (response.statusCode != 200) {
        throw Exception('WebDAV连接失败: ${response.statusCode}');
      }
      
    } catch (e) {
      throw Exception('WebDAV连接失败: $e');
    }
  }

  /// 模拟FTP连接
  Future<void> _connectViaFtp(NasConfig config) async {
    // 实际项目中需要使用FTP协议库
    await Future.delayed(const Duration(seconds: 1));
    
    // 模拟连接测试
    if (config.username.isEmpty || config.password.isEmpty) {
      throw Exception('用户名和密码不能为空');
    }
  }

  /// 获取NAS照片列表
  Future<List<PhotoModel>> _getNasPhotos(NasConfig config) async {
    // 模拟获取照片列表
    await Future.delayed(const Duration(seconds: 1));
    
    // 返回模拟数据
    return List.generate(20, (index) {
      final now = DateTime.now();
      final date = now.subtract(Duration(days: index * 7));
      
      return PhotoModel(
        id: 'nas_$index',
        filePath: '${config.sharePath}/photo_$index.jpg',
        createTime: date,
        width: 1920,
        height: 1080,
        fileSize: 1024.0 * (1 + index),
        exifInfo: '相机: Canon EOS R5\n光圈: f/2.8\n快门: 1/125s',
      );
    });
  }

  /// 下载照片缩略图
  Future<PhotoModel> _downloadPhotoThumbnail(PhotoModel photo, NasConfig config) async {
    // 模拟下载过程
    await Future.delayed(const Duration(milliseconds: 200));
    
    return photo;
  }

  /// Base64编码认证信息
  String _encodeCredentials(String username, String password) {
    final credentials = '$username:$password';
    final bytes = utf8.encode(credentials);
    return base64.encode(bytes);
  }

  /// 保存配置到本地存储
  Future<void> _saveConfigs() async {
    // 实际项目中应该保存到本地存储
    // 这里暂时使用内存存储
  }

  /// 从本地存储加载配置
  Future<void> loadConfigs() async {
    // 实际项目中应该从本地存储加载
    // 这里暂时使用模拟数据
    _nasConfigs = [
      NasConfig(
        id: '1',
        name: '家庭NAS',
        host: '192.168.1.100',
        username: 'admin',
        password: 'password',
        sharePath: '/photo',
        protocol: NasProtocol.smb,
        isDefault: true,
      ),
    ];
    notifyListeners();
  }

  /// 清除同步错误
  void clearError() {
    _syncError = null;
    notifyListeners();
  }
}