package com.example.memorypal_revive

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
