import 'package:flutter/material.dart';

/// 性能优化配置类
class PerformanceConfig {
  // 图片加载相关配置
  static const int maxImageCacheSize = 100; // 最大图片缓存数量
  static const int imageQuality = 80; // 图片质量百分比
  static const int thumbnailSize = 300; // 缩略图尺寸
  
  // 批量处理配置
  static const int batchSize = 20; // 批量处理大小
  static const int memoryCleanupThreshold = 100; // 内存清理阈值（MB）
  
  // 动画和交互配置
  static const Duration animationDuration = Duration(milliseconds: 300);
  static const Duration slideDuration = Duration(seconds: 5);
  
  // 平板设备特定配置
  static const int tabletMaxColumns = 6; // 平板最大列数
  static const int tabletMinColumns = 3; // 平板最小列数
  static const double tabletSpacing = 16.0; // 平板间距
  
  // 性能监控配置
  static const bool enablePerformanceMonitoring = true;
  static const Duration performanceCheckInterval = Duration(seconds: 5);
  
  // 内存管理配置
  static const int maxConcurrentOperations = 4; // 最大并发操作数
  static const bool enableMemoryOptimization = true;
  
  /// 根据设备类型获取优化的配置
  static Map<String, dynamic> getOptimizedConfig(bool isTablet) {
    return {
      'imageCacheSize': isTablet ? 150 : 100,
      'batchSize': isTablet ? 30 : 20,
      'animationDuration': isTablet 
          ? const Duration(milliseconds: 400) 
          : const Duration(milliseconds: 300),
      'maxColumns': isTablet ? 6 : 3,
      'spacing': isTablet ? 16.0 : 12.0,
    };
  }
  
  /// 获取设备性能等级
  static PerformanceLevel getPerformanceLevel(Size screenSize) {
    final shortestSide = screenSize.shortestSide;
    
    if (shortestSide > 900) {
      return PerformanceLevel.high;
    } else if (shortestSide > 600) {
      return PerformanceLevel.medium;
    } else {
      return PerformanceLevel.low;
    }
  }
}

/// 性能等级枚举
enum PerformanceLevel {
  low,    // 低性能设备（小屏手机）
  medium, // 中等性能设备（大屏手机、小屏平板）
  high,   // 高性能设备（大屏平板）
}

/// 平板设备检测工具
class TabletDetector {
  /// 检测是否为平板设备
  static bool isTablet(Size screenSize) {
    final shortestSide = screenSize.shortestSide;
    return shortestSide > 600;
  }
  
  /// 检测设备屏幕方向
  static bool isLandscape(Size screenSize) {
    return screenSize.width > screenSize.height;
  }
  
  /// 获取设备屏幕密度
  static double getScreenDensity(BuildContext context) {
    return MediaQuery.of(context).devicePixelRatio;
  }
  
  /// 获取设备屏幕尺寸分类
  static ScreenSize getScreenSize(Size screenSize) {
    final shortestSide = screenSize.shortestSide;
    
    if (shortestSide < 400) {
      return ScreenSize.small;
    } else if (shortestSide < 600) {
      return ScreenSize.normal;
    } else if (shortestSide < 900) {
      return ScreenSize.large;
    } else {
      return ScreenSize.extraLarge;
    }
  }
}

/// 屏幕尺寸分类
enum ScreenSize {
  small,       // 小屏手机
  normal,      // 标准手机
  large,       // 大屏手机/小屏平板
  extraLarge,  // 大屏平板
}

/// 响应式布局工具
class ResponsiveLayout {
  /// 根据屏幕尺寸获取列数
  static int getColumnCount(Size screenSize) {
    final screenSizeType = TabletDetector.getScreenSize(screenSize);
    
    switch (screenSizeType) {
      case ScreenSize.small:
        return 2;
      case ScreenSize.normal:
        return 3;
      case ScreenSize.large:
        return TabletDetector.isLandscape(screenSize) ? 5 : 4;
      case ScreenSize.extraLarge:
        return TabletDetector.isLandscape(screenSize) ? 6 : 5;
    }
  }
  
  /// 获取适合的字体大小
  static double getFontSize(Size screenSize, {double baseSize = 14}) {
    final screenSizeType = TabletDetector.getScreenSize(screenSize);
    
    switch (screenSizeType) {
      case ScreenSize.small:
        return baseSize;
      case ScreenSize.normal:
        return baseSize * 1.1;
      case ScreenSize.large:
        return baseSize * 1.2;
      case ScreenSize.extraLarge:
        return baseSize * 1.3;
    }
  }
  
  /// 获取适合的间距
  static double getSpacing(Size screenSize, {double baseSpacing = 8}) {
    final screenSizeType = TabletDetector.getScreenSize(screenSize);
    
    switch (screenSizeType) {
      case ScreenSize.small:
        return baseSpacing;
      case ScreenSize.normal:
        return baseSpacing * 1.2;
      case ScreenSize.large:
        return baseSpacing * 1.5;
      case ScreenSize.extraLarge:
        return baseSpacing * 2.0;
    }
  }
}