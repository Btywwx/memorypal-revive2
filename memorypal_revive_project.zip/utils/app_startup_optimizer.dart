import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:memorypal_revive/config/performance_config.dart';

/// 应用启动优化工具
class AppStartupOptimizer {
  /// 优化应用启动配置
  static Future<void> optimizeStartup() async {
    // 设置系统UI样式
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    
    // 设置系统UI覆盖样式
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.black,
      systemNavigationBarIconBrightness: Brightness.light,
    ));
    
    // 启用沉浸式模式
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }
  
  /// 预加载关键资源
  static Future<void> preloadResources() async {
    // 预加载字体
    await Future.wait([
      // 可以添加字体预加载
      Future.delayed(const Duration(milliseconds: 100)),
    ]);
  }
  
  /// 初始化性能监控
  static void initializePerformanceMonitoring() {
    if (PerformanceConfig.enablePerformanceMonitoring) {
      // 启用Flutter性能监控
      WidgetsFlutterBinding.ensureInitialized();
      
      // 设置图像缓存大小
      PaintingBinding.instance.imageCache.maximumSize = 
          PerformanceConfig.maxImageCacheSize;
      
      // 设置图像缓存大小字节
      PaintingBinding.instance.imageCache.maximumSizeBytes = 100 << 20; // 100MB
    }
  }
  
  /// 获取设备优化配置
  static Map<String, dynamic> getDeviceOptimizedConfig(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = TabletDetector.isTablet(screenSize);
    final performanceLevel = PerformanceConfig.getPerformanceLevel(screenSize);
    
    return {
      'isTablet': isTablet,
      'performanceLevel': performanceLevel,
      'screenSize': screenSize,
      'optimizedConfig': PerformanceConfig.getOptimizedConfig(isTablet),
      'columnCount': ResponsiveLayout.getColumnCount(screenSize),
      'fontSize': ResponsiveLayout.getFontSize(screenSize),
      'spacing': ResponsiveLayout.getSpacing(screenSize),
    };
  }
}

/// 平板设备启动优化
class TabletStartupOptimizer {
  /// 平板设备特定的启动优化
  static Future<void> optimizeForTablet() async {
    // 设置平板特定的配置
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    
    // 优化平板设备的系统UI
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.black,
      systemNavigationBarIconBrightness: Brightness.light,
    ));
  }
  
  /// 检测设备是否为高性能平板
  static bool isHighPerformanceTablet(Size screenSize) {
    return TabletDetector.isTablet(screenSize) && 
           PerformanceConfig.getPerformanceLevel(screenSize) == PerformanceLevel.high;
  }
  
  /// 获取平板优化配置
  static Map<String, dynamic> getTabletOptimizedConfig(Size screenSize) {
    final isHighPerformance = isHighPerformanceTablet(screenSize);
    
    return {
      'imageCacheSize': isHighPerformance ? 200 : 150,
      'batchSize': isHighPerformance ? 40 : 30,
      'animationDuration': isHighPerformance 
          ? const Duration(milliseconds: 500) 
          : const Duration(milliseconds: 400),
      'maxColumns': ResponsiveLayout.getColumnCount(screenSize),
      'spacing': ResponsiveLayout.getSpacing(screenSize, baseSpacing: 16),
      'fontSize': ResponsiveLayout.getFontSize(screenSize, baseSize: 16),
    };
  }
}

/// 内存管理工具
class MemoryManager {
  static final List<Function> _cleanupCallbacks = [];
  
  /// 注册清理回调
  static void registerCleanupCallback(Function callback) {
    _cleanupCallbacks.add(callback);
  }
  
  /// 执行内存清理
  static void cleanupMemory() {
    // 清理图片缓存
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    
    // 执行注册的清理回调
    for (final callback in _cleanupCallbacks) {
      try {
        callback();
      } catch (e) {
        // 忽略清理回调中的错误
      }
    }
    
    // 触发垃圾回收（在支持的平台上）
    _triggerGarbageCollection();
  }
  
  /// 触发垃圾回收
  static void _triggerGarbageCollection() {
    // 在Flutter中，垃圾回收是自动的
    // 这里可以添加平台特定的垃圾回收触发
  }
  
  /// 检查内存使用情况
  static String getMemoryUsage() {
    // 这里可以集成真实的内存监控
    return '内存使用正常';
  }
  
  /// 优化内存使用
  static void optimizeMemoryUsage() {
    if (PerformanceConfig.enableMemoryOptimization) {
      // 定期清理内存
      cleanupMemory();
    }
  }
}

/// 性能分析工具
class PerformanceAnalyzer {
  static final Map<String, int> _operationCounts = {};
  static final Map<String, Duration> _operationDurations = {};
  
  /// 开始性能分析
  static void startAnalysis(String operationName) {
    _operationCounts[operationName] = (_operationCounts[operationName] ?? 0) + 1;
  }
  
  /// 记录操作耗时
  static void recordDuration(String operationName, Duration duration) {
    _operationDurations[operationName] = duration;
  }
  
  /// 获取性能报告
  static Map<String, dynamic> getPerformanceReport() {
    return {
      'operationCounts': _operationCounts,
      'operationDurations': _operationDurations,
      'memoryUsage': MemoryManager.getMemoryUsage(),
    };
  }
  
  /// 重置性能数据
  static void reset() {
    _operationCounts.clear();
    _operationDurations.clear();
  }
}