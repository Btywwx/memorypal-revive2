import 'dart:async';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// 性能监控工具类
class PerformanceMonitor {
  static final PerformanceMonitor _instance = PerformanceMonitor._internal();
  factory PerformanceMonitor() => _instance;
  PerformanceMonitor._internal();

  final Map<String, PerformanceTracker> _trackers = {};
  bool _isMonitoring = false;
  Timer? _memoryMonitorTimer;

  /// 开始性能监控
  void startMonitoring() {
    if (_isMonitoring) return;
    
    _isMonitoring = true;
    
    // 启动内存监控
    _memoryMonitorTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _logMemoryUsage();
    });
    
    if (kDebugMode) {
      debugPrint('🚀 性能监控已启动');
    }
  }

  /// 停止性能监控
  void stopMonitoring() {
    _isMonitoring = false;
    _memoryMonitorTimer?.cancel();
    _trackers.clear();
    
    if (kDebugMode) {
      debugPrint('🛑 性能监控已停止');
    }
  }

  /// 开始跟踪一个操作
  PerformanceTracker startTracking(String operationName) {
    final tracker = PerformanceTracker(operationName);
    _trackers[operationName] = tracker;
    return tracker;
  }

  /// 结束跟踪并记录结果
  void endTracking(String operationName) {
    final tracker = _trackers[operationName];
    if (tracker != null) {
      tracker.end();
      _logPerformance(tracker);
      _trackers.remove(operationName);
    }
  }

  /// 记录内存使用情况
  void _logMemoryUsage() {
    if (!_isMonitoring) return;
    
    // 在调试模式下记录内存使用情况
    if (kDebugMode) {
      debugPrint('💾 内存使用情况: ${_getMemoryUsage()}');
    }
  }

  /// 记录性能数据
  void _logPerformance(PerformanceTracker tracker) {
    if (!_isMonitoring) return;
    
    if (kDebugMode) {
      final duration = tracker.duration.inMilliseconds;
      final memory = _getMemoryUsage();
      
      if (duration > 100) {
        // 超过100ms的操作需要记录警告
        debugPrint('⚠️ 性能警告: ${tracker.name} 耗时 ${duration}ms (内存: $memory)');
      } else if (duration > 50) {
        // 超过50ms的操作记录信息
        debugPrint('ℹ️ 性能信息: ${tracker.name} 耗时 ${duration}ms (内存: $memory)');
      }
    }
  }

  /// 获取当前内存使用情况（模拟实现）
  String _getMemoryUsage() {
    // 这里可以集成真实的内存监控工具
    return '${DateTime.now().millisecondsSinceEpoch % 1000}MB';
  }

  /// 检查当前性能状态
  PerformanceStatus getCurrentStatus() {
    final currentTime = DateTime.now();
    final slowOperations = _trackers.values
        .where((tracker) => tracker.startTime.difference(currentTime).inSeconds > 10)
        .length;
    
    if (slowOperations > 3) {
      return PerformanceStatus.critical;
    } else if (slowOperations > 1) {
      return PerformanceStatus.warning;
    } else {
      return PerformanceStatus.normal;
    }
  }
}

/// 性能跟踪器
class PerformanceTracker {
  final String name;
  final DateTime startTime;
  late DateTime? _endTime;

  PerformanceTracker(this.name) : startTime = DateTime.now();

  /// 结束跟踪
  void end() {
    _endTime = DateTime.now();
  }

  /// 获取耗时
  Duration get duration {
    final endTime = _endTime ?? DateTime.now();
    return endTime.difference(startTime);
  }

  /// 检查是否超时
  bool get isTimeout {
    return duration.inSeconds > 30; // 30秒超时
  }
}

/// 性能状态枚举
enum PerformanceStatus {
  normal,    // 正常
  warning,   // 警告
  critical,  // 严重
}

/// 性能优化工具
class PerformanceOptimizer {
  /// 批量处理列表，避免一次性处理大量数据
  static Future<List<T>> processInBatches<T>(
    List<T> items,
    Future<T> Function(T) processFunction,
    int batchSize,
  ) async {
    final results = <T>[];
    
    for (int i = 0; i < items.length; i += batchSize) {
      final batch = items.sublist(
        i, 
        i + batchSize > items.length ? items.length : i + batchSize
      );
      
      final batchResults = await Future.wait(
        batch.map(processFunction),
      );
      
      results.addAll(batchResults);
      
      // 给UI线程处理时间
      await Future.delayed(const Duration(milliseconds: 10));
    }
    
    return results;
  }

  /// 图片缓存优化
  static ImageProvider optimizeImageLoading(
    String imagePath, {
    int? width,
    int? height,
    bool enableCache = true,
  }) {
    return ResizeImage.resizeIfNeeded(
      width,
      height,
      FileImage(File(imagePath)),
    );
  }

  /// 内存清理工具
  static void cleanupMemory() {
    // 强制垃圾回收（在Flutter中需要特殊处理）
    if (kDebugMode) {
      debugPrint('🧹 执行内存清理');
    }
    
    // 清理图片缓存
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
  }

  /// 检查是否为高性能设备
  static bool isHighPerformanceDevice(Size screenSize) {
    final shortestSide = screenSize.shortestSide;
    final longestSide = screenSize.longestSide;
    
    // 平板设备通常有更大的屏幕和更好的性能
    return shortestSide > 600 && longestSide > 900;
  }

  /// 根据设备性能调整图片质量
  static double getOptimizedImageQuality(Size screenSize) {
    if (isHighPerformanceDevice(screenSize)) {
      return 0.8; // 高性能设备使用较高质量
    } else {
      return 0.6; // 低性能设备使用较低质量
    }
  }
}