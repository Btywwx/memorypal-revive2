import 'dart:io';
import 'package:flutter/material.dart';
import 'package:memorypal_revive/models/photo_model.dart';
import 'package:memorypal_revive/utils/performance_monitor.dart';
import 'package:cached_network_image/cached_network_image.dart';

/// 照片网格组件 - 为平板设备优化
class PhotoGrid extends StatefulWidget {
  final List<PhotoModel> photos;
  final Function(PhotoModel) onPhotoTap;
  final bool enablePerformanceMonitoring;

  const PhotoGrid({
    super.key,
    required this.photos,
    required this.onPhotoTap,
    this.enablePerformanceMonitoring = true,
  });

  @override
  State<PhotoGrid> createState() => _PhotoGridState();
}

class _PhotoGridState extends State<PhotoGrid> {
  late PerformanceMonitor _performanceMonitor;
  
  @override
  void initState() {
    super.initState();
    _performanceMonitor = PerformanceMonitor();
    if (widget.enablePerformanceMonitoring) {
      _performanceMonitor.startMonitoring();
    }
  }

  @override
  void dispose() {
    if (widget.enablePerformanceMonitoring) {
      _performanceMonitor.stopMonitoring();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final crossAxisCount = _getCrossAxisCount(screenSize);
    
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 0.75,
      ),
      itemCount: widget.photos.length,
      itemBuilder: (context, index) {
        final photo = widget.photos[index];
        return _buildPhotoCard(photo, index);
      },
    );
  }

  /// 根据屏幕尺寸确定网格列数
  int _getCrossAxisCount(Size screenSize) {
    final shortestSide = screenSize.shortestSide;
    
    if (shortestSide > 1200) {
      return 6; // 大平板
    } else if (shortestSide > 900) {
      return 5; // 中等平板
    } else if (shortestSide > 600) {
      return 4; // 小平板
    } else {
      return 3; // 手机
    }
  }

  /// 构建照片卡片
  Widget _buildPhotoCard(PhotoModel photo, int index) {
    return GestureDetector(
      onTap: () => widget.onPhotoTap(photo),
      child: Hero(
        tag: 'photo_${photo.id}',
        child: Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Stack(
            children: [
              // 图片
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: _buildPhotoImage(photo),
              ),
              
              // 叠加信息
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withOpacity(0.7),
                        Colors.transparent,
                      ],
                    ),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(12),
                      bottomRight: Radius.circular(12),
                    ),
                  ),
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (photo.createTime != null)
                        Text(
                          _formatDate(photo.createTime!),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      if (photo.fileSize != null)
                        Text(
                          '${(photo.fileSize! / 1024 / 1024).toStringAsFixed(1)} MB',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 10,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 构建图片显示
  Widget _buildPhotoImage(PhotoModel photo) {
    // 如果是网络图片
    if (photo.filePath.startsWith('http')) {
      return CachedNetworkImage(
        imageUrl: photo.filePath,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        placeholder: (context, url) => Container(
          color: Colors.grey.shade300,
          child: const Center(
            child: CircularProgressIndicator(),
          ),
        ),
        errorWidget: (context, url, error) => Container(
          color: Colors.grey.shade200,
          child: const Center(
            child: Icon(Icons.error, color: Colors.grey),
          ),
        ),
      );
    } else {
      // 本地文件
      return Image.file(
        File(photo.filePath),
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (context, error, stackTrace) => Container(
          color: Colors.grey.shade200,
          child: const Center(
            child: Icon(Icons.broken_image, color: Colors.grey),
          ),
        ),
      );
    }
  }

  /// 格式化日期
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      return '今天';
    } else if (difference.inDays == 1) {
      return '昨天';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}天前';
    } else {
      return '${date.year}年${date.month}月${date.day}日';
    }
  }
}

/// 平板优化布局组件
class TabletOptimizedLayout extends StatelessWidget {
  final Widget child;
  final bool enableLandscapeMode;

  const TabletOptimizedLayout({
    super.key,
    required this.child,
    this.enableLandscapeMode = true,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isTablet = constraints.maxWidth > 600;
        
        if (isTablet && enableLandscapeMode) {
          return _buildTabletLayout();
        } else {
          return child;
        }
      },
    );
  }

  Widget _buildTabletLayout() {
    return Container(
      constraints: const BoxConstraints.expand(),
      child: Column(
        children: [
          // 顶部状态栏区域
          Container(
            height: 60,
            color: Colors.transparent,
            child: const Center(
              child: Text(
                '忆景Revive - 智能相册',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          
          // 主要内容区域
          Expanded(
            child: child,
          ),
          
          // 底部控制栏
          Container(
            height: 80,
            color: Colors.transparent,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildControlButton(Icons.home, '首页'),
                _buildControlButton(Icons.photo_library, '相册'),
                _buildControlButton(Icons.slideshow, '幻灯片'),
                _buildControlButton(Icons.settings, '设置'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton(IconData icon, String label) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}