import 'dart:io';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:memorypal_revive/utils/performance_monitor.dart';

/// 平板设备优化布局组件
class TabletOptimizedLayout extends StatelessWidget {
  final Widget child;
  final bool enablePerformanceMonitoring;

  const TabletOptimizedLayout({
    super.key,
    required this.child,
    this.enablePerformanceMonitoring = true,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final performanceMonitor = PerformanceMonitor();
        final isTablet = constraints.maxWidth > 600;
        
        if (isTablet) {
          if (enablePerformanceMonitoring) {
            performanceMonitor.startTracking('tablet_layout_optimization');
          }
          
          final optimizedChild = _buildTabletLayout(context);
          
          if (enablePerformanceMonitoring) {
            performanceMonitor.endTracking('tablet_layout_optimization');
          }
          
          return optimizedChild;
        } else {
          return child;
        }
      },
    );
  }

  Widget _buildTabletLayout(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    
    return Container(
      constraints: const BoxConstraints.expand(),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.blue.shade800.withOpacity(0.1),
            Colors.purple.shade800.withOpacity(0.1),
            Colors.pink.shade800.withOpacity(0.1),
          ],
        ),
      ),
      child: Column(
        children: [
          // 顶部状态栏（平板专属）
          _buildTabletStatusBar(context, orientation),
          
          // 主要内容区域
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white.withOpacity(0.05),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: child,
                ),
              ),
            ),
          ),
          
          // 底部控制栏（平板专属）
          if (orientation == Orientation.landscape)
            _buildTabletControlBar(context),
        ],
      ),
    );
  }

  /// 构建平板状态栏
  Widget _buildTabletStatusBar(BuildContext context, Orientation orientation) {
    return Container(
      height: orientation == Orientation.portrait ? 80 : 60,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withOpacity(0.3),
            Colors.transparent,
          ],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          child: Row(
            children: [
              // 应用标题
              Expanded(
                child: Text(
                  '忆景Revive - 智能相册',
                  style: TextStyle(
                    fontSize: orientation == Orientation.portrait ? 24 : 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        blurRadius: 10,
                        color: Colors.black.withOpacity(0.5),
                      ),
                    ],
                  ),
                ),
              ),
              
              // 状态信息
              Row(
                children: [
                  _buildStatusItem(Icons.access_time, '${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}'),
                  const SizedBox(width: 16),
                  _buildStatusItem(Icons.battery_std, '100%'),
                  const SizedBox(width: 16),
                  _buildStatusItem(Icons.signal_wifi_4_bar, 'WiFi'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 构建状态项
  Widget _buildStatusItem(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: Colors.white, size: 16),
        const SizedBox(width: 4),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  /// 构建平板控制栏
  Widget _buildTabletControlBar(BuildContext context) {
    return Container(
      height: 100,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            Colors.black.withOpacity(0.3),
            Colors.transparent,
          ],
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildTabletControlButton(
                Icons.photo_library,
                '照片库',
                () => _navigateToGallery(context),
              ),
              _buildTabletControlButton(
                Icons.slideshow,
                '幻灯片',
                () => _navigateToSlideshow(context),
              ),
              _buildTabletControlButton(
                Icons.photo_album,
                '相册',
                () => _navigateToAlbums(context),
              ),
              _buildTabletControlButton(
                Icons.settings,
                '设置',
                () => _navigateToSettings(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 构建平板控制按钮
  Widget _buildTabletControlButton(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white.withOpacity(0.1),
              Colors.white.withOpacity(0.05),
            ],
          ),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 导航到照片库
  void _navigateToGallery(BuildContext context) {
    // 这里可以添加导航逻辑
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('导航到照片库')),
    );
  }

  /// 导航到幻灯片
  void _navigateToSlideshow(BuildContext context) {
    // 这里可以添加导航逻辑
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('导航到幻灯片播放')),
    );
  }

  /// 导航到相册
  void _navigateToAlbums(BuildContext context) {
    // 这里可以添加导航逻辑
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('导航到相册管理')),
    );
  }

  /// 导航到设置
  void _navigateToSettings(BuildContext context) {
    // 这里可以添加导航逻辑
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('导航到设置')),
    );
  }
}

/// 平板优化的图片查看器
class TabletOptimizedImageViewer extends StatelessWidget {
  final String imagePath;
  final bool isNetworkImage;
  final Function()? onPrevious;
  final Function()? onNext;

  const TabletOptimizedImageViewer({
    super.key,
    required this.imagePath,
    this.isNetworkImage = false,
    this.onPrevious,
    this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;
    
    return Stack(
      children: [
        // 背景
        Container(
          color: Colors.black,
          child: Center(
            child: isNetworkImage
                ? Image.network(
                    imagePath,
                    fit: BoxFit.contain,
                    width: screenSize.width,
                    height: screenSize.height,
                  )
                : Image.file(
                    File(imagePath),
                    fit: BoxFit.contain,
                    width: screenSize.width,
                    height: screenSize.height,
                  ),
          ),
        ),
        
        // 控制按钮（仅在横屏时显示侧边按钮）
        if (isLandscape)
          Positioned(
            left: 20,
            top: 0,
            bottom: 0,
            child: Container(
              width: 80,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (onPrevious != null)
                    _buildSideControlButton(Icons.arrow_back_ios, '上一张', onPrevious!),
                ],
              ),
            ),
          ),
        
        if (isLandscape)
          Positioned(
            right: 20,
            top: 0,
            bottom: 0,
            child: Container(
              width: 80,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (onNext != null)
                    _buildSideControlButton(Icons.arrow_forward_ios, '下一张', onNext!),
                ],
              ),
            ),
          ),
        
        // 顶部信息栏
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: Container(
            height: 100,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.8),
                  Colors.transparent,
                ],
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Row(
                  children: [
                    // 返回按钮
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    
                    const Spacer(),
                    
                    // 图片信息
                    Text(
                      '图片详情',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    
                    const Spacer(),
                    
                    // 操作按钮
                    IconButton(
                      icon: const Icon(Icons.info_outline, color: Colors.white, size: 28),
                      onPressed: () => _showImageInfo(context),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// 构建侧边控制按钮
  Widget _buildSideControlButton(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.white.withOpacity(0.1),
          border: Border.all(
            color: Colors.white.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 24),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 显示图片信息
  void _showImageInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('图片信息'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('路径: $imagePath'),
            Text('类型: ${isNetworkImage ? '网络图片' : '本地文件'}'),
            const Text('大小: 2.4 MB'),
            const Text('分辨率: 1920x1080'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }
}