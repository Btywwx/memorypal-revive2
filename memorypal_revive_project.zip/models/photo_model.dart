import 'package:flutter/foundation.dart';

/// 照片模型类
class PhotoModel {
  final String id;
  final String filePath;
  final String? thumbnailPath;
  final DateTime? createTime;
  final int? width;
  final int? height;
  final double? fileSize;
  final String? exifInfo;

  PhotoModel({
    required this.id,
    required this.filePath,
    this.thumbnailPath,
    this.createTime,
    this.width,
    this.height,
    this.fileSize,
    this.exifInfo,
  });

  /// 从Map创建PhotoModel
  factory PhotoModel.fromMap(Map<String, dynamic> map) {
    return PhotoModel(
      id: map['id'] ?? '',
      filePath: map['filePath'] ?? '',
      thumbnailPath: map['thumbnailPath'],
      createTime: map['createTime'] != null ? DateTime.parse(map['createTime']) : null,
      width: map['width'],
      height: map['height'],
      fileSize: map['fileSize']?.toDouble(),
      exifInfo: map['exifInfo'],
    );
  }

  /// 转换为Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'filePath': filePath,
      'thumbnailPath': thumbnailPath,
      'createTime': createTime?.toIso8601String(),
      'width': width,
      'height': height,
      'fileSize': fileSize,
      'exifInfo': exifInfo,
    };
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is PhotoModel && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'PhotoModel(id: $id, filePath: $filePath)';
  }
}