import 'package:flutter/foundation.dart';

/// NAS配置模型
class NasConfig {
  final String id;
  final String name;
  final String host;
  final int port;
  final String username;
  final String password;
  final String sharePath;
  final NasProtocol protocol;
  final bool isDefault;

  NasConfig({
    required this.id,
    required this.name,
    required this.host,
    this.port = 445,
    required this.username,
    required this.password,
    required this.sharePath,
    this.protocol = NasProtocol.smb,
    this.isDefault = false,
  });

  /// 从Map创建NasConfig
  factory NasConfig.fromMap(Map<String, dynamic> map) {
    return NasConfig(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      host: map['host'] ?? '',
      port: map['port'] ?? 445,
      username: map['username'] ?? '',
      password: map['password'] ?? '',
      sharePath: map['sharePath'] ?? '',
      protocol: NasProtocol.values.firstWhere(
        (e) => e.name == (map['protocol'] ?? 'smb'),
        orElse: () => NasProtocol.smb,
      ),
      isDefault: map['isDefault'] ?? false,
    );
  }

  /// 转换为Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'host': host,
      'port': port,
      'username': username,
      'password': password,
      'sharePath': sharePath,
      'protocol': protocol.name,
      'isDefault': isDefault,
    };
  }

  /// 获取连接URL
  String get connectionUrl {
    switch (protocol) {
      case NasProtocol.smb:
        return 'smb://$host:$port$sharePath';
      case NasProtocol.webdav:
        return 'http://$host:$port$sharePath';
      case NasProtocol.ftp:
        return 'ftp://$host:$port$sharePath';
    }
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is NasConfig && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'NasConfig(id: $id, name: $name, host: $host)';
  }
}

/// NAS协议类型
enum NasProtocol {
  smb,    // SMB/CIFS协议
  webdav, // WebDAV协议
  ftp,    // FTP协议
}

/// NAS连接状态
enum NasConnectionStatus {
  disconnected, // 未连接
  connecting,   // 连接中
  connected,    // 已连接
  error,        // 连接错误
}